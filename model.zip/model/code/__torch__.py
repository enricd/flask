class Model(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  labels : List[str]
  resnet : __torch__.torchvision.models.resnet.ResNet
  def forward(self: __torch__.Model,
    x: Tensor) -> Tensor:
    return (self.resnet).forward(x, )
